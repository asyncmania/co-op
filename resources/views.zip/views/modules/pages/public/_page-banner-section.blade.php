<section class="breadcrumbs overlay">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2>{{$page->title}}</h2>
                <ul class="bread-list">
                    <li><a href="{{url('/')}}">Home<i class="fa fa-angle-right"></i></a></li>
                    <li class="active"><a href="#">{{$page->title}}</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
