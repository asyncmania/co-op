<a href="{!! $page->present()->url !!}">
    <i class="licon-arrow-left"></i>
</a>