@extends('pages::public.master')
@section('page')
    @include('pages::public._page-banner-section')
    @include('pages::public._page-content')
@stop