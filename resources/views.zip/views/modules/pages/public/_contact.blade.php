<div class="tg-widget tg-widgetreadytohelp">
    <h3>Always Ready To Help!</h3>
    <div class="tg-description">
        <p> 30 Raymond Njoku Street, Off Awolowo Road, Ikoyi, Lagos @ <a href="query%40domain.html">info@jnciltd.com</a> OR call us anytime 01-4630227.</p>
    </div>
    <a href="#">Contact Now!</a>
</div>