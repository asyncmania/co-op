<div class="widget">
    <h4 class="widget-title">Subscribe to our Newsletter</h4>
    <div class="widget-content">
        <p class="is-spaced">Join our mailing list to get updated</p>
        <div class="field has-addons">
            <div class="control is-expanded">
                <input class="input" type="text" placeholder="Enter email address">
            </div>
            <div class="control">
                <a class="button is-info">
                    <span class="icon"><i class="fa fa-paper-plane"></i></span>
                </a>
            </div>
        </div>
    </div>
</div>