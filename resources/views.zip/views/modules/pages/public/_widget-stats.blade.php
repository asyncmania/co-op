<div class="widget-stats">
    <div class="columns">
        <div class="column">
            <div class="cmp-overview">
                <div class="cmp-icon">
                    <i class="cmp-i icon-search"></i>
                    <i class="fa fa-check"></i>
                </div>
                <div class="cmp-detail">
                    <h3>0</h3>
                    <span>Active Employers</span>
                </div>
            </div>
        </div>
        <div class="column">
            <div class="cmp-overview">
                <div class="cmp-icon">
                    <i class="cmp-i icon-profile-male"></i>
                    <i class="fa fa-check"></i>
                </div>
                <div class="cmp-detail">
                    <h3>0</h3>
                    <span>Active Service Providers</span>
                </div>
            </div>
        </div>
        <div class="column">
            <div class="cmp-overview">
                <div class="cmp-icon">
                    <i class="cmp-i icon-global"></i>
                    <i class="fa fa-check"></i>
                </div>
                <div class="cmp-detail">
                    <h3>0</h3>
                    <span>Successful Requests</span>
                </div>
            </div>
        </div>
    </div>
</div>