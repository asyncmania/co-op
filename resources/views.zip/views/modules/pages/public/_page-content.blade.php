<section class="about-us section">
    <div class="container">
        @include('pages::public._page-content-title')
        @include('pages::public._page-content-body')
    </div>
</section>