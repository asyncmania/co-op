@if(!empty($page->body))
    <div class="about-text">
        {!! $page->body !!}
    </div>
@endif
