
<li>{{ $model->company }}</li>
<li>{{ $model->address }}</li>
<li>{{ $model->tag }}</li>
<li>{{ $model->website }}</li>
<li>{{ $model->body }}</li>
<li>{{ $model->email }}</li>
<li>{{ $model->phone }}</li>