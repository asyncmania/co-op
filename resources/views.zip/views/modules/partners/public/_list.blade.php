<div class="testimonial-holder list-style">
    @foreach ($models as $model)
        @include('partners::public._list-item')
    @endforeach
</div>

