<div class="class-item row">
    <div class="class-item-col col-md-4">
        <div class="class-item-title">Description</div>
        <div class="class-item-content">
            {!! $class->body !!}
        </div>
    </div>
    <div class="class-item-col col-md">
        <div class="class-item-title">Date</div>
        <div class="class-item-content">
            {!! $class->present()->formatedDate() !!}
        </div>
    </div>
    <div class="class-item-col col-md">
        <div class="class-item-title">Price</div>
        <div class="class-item-content price">
            ${!! $class->present()->price !!}
        </div>
    </div>
    @if(empty($checkout))
        <div class="class-item-col col-md">
            <div class="class-item-title"></div>
            <div class="class-item-content button">
                {{Form::open(['route'=>'cart.add'])}}
                {{Form::hidden('class_id',$class->id)}}
                <button type="submit" class="btn">Register</button>
                {{Form::close()}}
            </div>
        </div>
    @endif
</div>