<ul>
    @foreach($groups as $group)
        {!! $group !!}
    @endforeach
</ul>
