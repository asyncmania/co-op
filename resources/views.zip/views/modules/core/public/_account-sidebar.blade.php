<div class="account-nav tabs is-boxed is-centered">
    {!! $sidebar !!}
</div>
