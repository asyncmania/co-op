<div class="testimonial-slider">
    @foreach ($models as $model)
        @include('testimonials::public._list-item')
    @endforeach
</div>

