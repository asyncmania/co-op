<div class="single-testimonial">
    <img src="{!! $model->present()->thumbSrc(80,80) !!}" alt="#">
    <div class="main-content">
        <h4 class="name">{!! $model->name !!}</h4>
        {!! $model->body !!}
    </div>
</div>